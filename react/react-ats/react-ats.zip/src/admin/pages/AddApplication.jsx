import React from 'react'

const AddApplication = () => {
    return (
        <div>AddApplication</div>
    )
}

export default AddApplication