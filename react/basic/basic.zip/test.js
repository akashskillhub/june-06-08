const fn = arg => { }
fn("dell")