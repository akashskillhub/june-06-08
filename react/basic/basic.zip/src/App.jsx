import Myjsx from "./01_jsx/Myjsx"
import Practice from "./01_jsx/Practice"
import Myprops from "./02_props/Myprops"
import Mystate from "./03_state/Mystate"
import Myevent from "./04_event/Myevent"

const App = () => {
  const arr = ["ross", "joe", "rachel"]
  return <div>
    {/* <Myjsx /> */}
    {/* <Practice /> */}
    {/* <Myprops
      brand="dell"
      price={500}
      users={arr} /> */}
    <Mystate />
    {/* <Myevent /> */}
  </div>
}
export default App