import React from 'react'

const Dashboard = () => {
    return <>
        <button>+add</button>
    </>
}

export default Dashboard