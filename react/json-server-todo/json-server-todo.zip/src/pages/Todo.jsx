import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { toast } from 'react-toastify'

const Todo = () => {
    const [isLoading, setIsLoading] = useState(false)
    const [allTodos, setAllTodos] = useState()
    const [task, setTask] = useState()
    const handleAddTodo = async e => {
        try {
            await axios.post("http://localhost:5000/todos", { task })
            toast.success("todo create success")
            getAllTodos()
        } catch (error) {
            toast.error(error.message)
        }
    }
    const getAllTodos = async e => {
        try {
            setIsLoading(true)
            // setTimeout(async () => {
            const { data } = await axios.get("http://localhost:5000/todos")
            setAllTodos(data)
            setIsLoading(false)

            // }, 5000);
        } catch (error) {
            console.log(error)
            setIsLoading(false)
        }
    }

    const handleDelete = async todoId => {
        try {
            const { data } = await axios.delete(`http://localhost:5000/todos/${todoId}`)
            toast.success("todo delete success");
            getAllTodos()

        } catch (error) {
            toast.error(error.message);

        }
    }
    useEffect(() => {
        getAllTodos()
    }, [])

    const TODO_TABLE = <>
        <table border={1}>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Task</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                {allTodos && allTodos.map(item => <tr key={item.id}>
                    <td>{item.id}</td>
                    <td>{item.task}</td>
                    <td>
                        <button>edit</button>
                        <button onClick={e => handleDelete(item.id)}>delete</button>
                    </td>
                </tr>)}
            </tbody>
        </table>
    </>
    if (isLoading) return <h1>Loading.....</h1>
    return <>

        <input type="text" onChange={e => setTask(e.target.value)} />
        <button onClick={handleAddTodo}>add</button>
        <hr />
        {TODO_TABLE}
    </>
}

export default Todo